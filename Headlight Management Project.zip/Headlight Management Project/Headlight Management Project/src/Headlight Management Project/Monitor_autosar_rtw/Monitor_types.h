/*
 * File: Monitor_types.h
 *
 * Code generated for Simulink model 'Monitor'.
 *
 * Model version                  : 1.5
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Sun Sep 29 02:26:14 2024
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef Monitor_types_h_
#define Monitor_types_h_
#include "Rte_Type.h"
#endif                                 /* Monitor_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

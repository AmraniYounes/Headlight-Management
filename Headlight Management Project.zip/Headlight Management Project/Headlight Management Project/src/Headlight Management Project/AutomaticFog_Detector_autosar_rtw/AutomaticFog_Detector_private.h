/*
 * File: AutomaticFog_Detector_private.h
 *
 * Code generated for Simulink model 'AutomaticFog_Detector'.
 *
 * Model version                  : 1.11
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Sun Sep 29 02:23:31 2024
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef AutomaticFog_Detector_private_h_
#define AutomaticFog_Detector_private_h_
#include "Platform_Types.h"
#include "AutomaticFog_Detector_types.h"
#endif                                 /* AutomaticFog_Detector_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

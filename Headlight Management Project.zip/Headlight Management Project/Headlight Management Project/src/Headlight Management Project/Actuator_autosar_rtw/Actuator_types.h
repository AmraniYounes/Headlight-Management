/*
 * File: Actuator_types.h
 *
 * Code generated for Simulink model 'Actuator'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Sun Sep 29 02:19:25 2024
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef Actuator_types_h_
#define Actuator_types_h_
#endif                                 /* Actuator_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

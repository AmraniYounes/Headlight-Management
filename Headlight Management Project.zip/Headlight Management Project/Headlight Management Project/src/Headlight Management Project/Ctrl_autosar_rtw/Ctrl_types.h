/*
 * File: Ctrl_types.h
 *
 * Code generated for Simulink model 'Ctrl'.
 *
 * Model version                  : 1.6
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Sun Sep 29 02:19:59 2024
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef Ctrl_types_h_
#define Ctrl_types_h_
#endif                                 /* Ctrl_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

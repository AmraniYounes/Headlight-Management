/*
 * File: Ctrl_private.h
 *
 * Code generated for Simulink model 'Ctrl'.
 *
 * Model version                  : 1.6
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Sun Sep 29 02:19:59 2024
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef Ctrl_private_h_
#define Ctrl_private_h_
#include "Platform_Types.h"
#include "Ctrl_types.h"
#endif                                 /* Ctrl_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
